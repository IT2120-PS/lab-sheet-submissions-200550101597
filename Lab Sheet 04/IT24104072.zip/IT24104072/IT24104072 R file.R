setwd("C:\\Users\\IT24104072\\Desktop\\IT24104072")
branch_data <- read.table("Exercise.txt", header = TRUE)
getwd()

setwd("C:\\Users\\IT24104081\\Desktop\\IT24104072")
branch_data <- read.csv("Exercise.txt")

# Step 2: View the structure of the data
str(branch_data)

# Step 3: Create a boxplot for the Sales_X1 variable
boxplot(branch_data$Sales_X1, 
        main = "Boxplot of Sales_X1", 
        ylab = "Sales", 
        col = "lightblue", 
        horizontal = TRUE)

# Step 4: Summarize the Advertising_X2 variable
summary(branch_data$Advertising_X2)

# Step 5: Calculate IQR for the Advertising_X2 variable
IQR(branch_data$Advertising_X2)

# Step 6: Define a function to detect outliers using the 1.5*IQR rule
find_outliers <- function(x) {
  Q1 <- quantile(x, 0.25)   # First Quartile (25th percentile)
  Q3 <- quantile(x, 0.75)   # Third Quartile (75th percentile)
  IQR_value <- IQR(x)       # Interquartile Range (Q3 - Q1)
  
  lower_bound <- Q1 - 1.5 * IQR_value  # Lower bound for outliers
  upper_bound <- Q3 + 1.5 * IQR_value  # Upper bound for outliers
  
  # Identify outliers: values less than the lower bound or greater than the upper bound
  outliers <- x[x < lower_bound | x > upper_bound]
  
  return(outliers)
}

# Step 7: Check for outliers in Advertising_X2
outliers_advertising_x2 <- find_outliers(branch_data$Advertising_X2)
cat("Outliers in Advertising_X2: ", outliers_advertising_x2, "\n")

# Step 8: Check for outliers in Years_X3
outliers_years_x3 <- find_outliers(branch_data$Years_X3)
cat("Outliers in Years_X3: ", outliers_years_x3, "\n")

# Step 9: Check if there are any outliers for Sales_X1
outliers_sales_x1 <- find_outliers(branch_data$Sales_X1)
cat("Outliers in Sales_X1: ", outliers_sales_x1, "\n")  

